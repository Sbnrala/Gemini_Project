
import React, { useState, useEffect, useRef } from 'react';
import { AppView, Professional, Project, ChatMessage, DriveFile, BroadcastRequest, Collection, Invoice, WallPost, SavedCard, BankAccount } from './types';
import { MOCK_PROS, INITIAL_PROJECTS, MOCK_WALL_POSTS } from './constants';
import { Whiteboard } from './components/Whiteboard';
import { GoogleDrivePicker } from './components/GoogleDrivePicker';
import { CameraCapture } from './components/CameraCapture';
import { ExpertDashboard } from './components/ExpertDashboard';
import { BuildersWall } from './components/BuildersWall';
import { LocalExpertsList } from './components/LocalExpertsList';
import { ProfileView } from './components/ProfileView';
import { ClientSettingsView } from './components/ClientSettingsView';
import { InvoiceModal } from './components/InvoiceModal';
import { MultiOfferModal } from './components/MultiOfferModal';
import { geminiService } from './services/geminiService';
import { LiveCallSession } from './services/liveService';

interface AppNotification {
  id: string;
  message: string;
  type: 'offer' | 'info' | 'success';
}

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<'client' | 'expert'>('client');
  const [currentView, setCurrentView] = useState<AppView>(AppView.WORKSPACE);
  
  // PERSISTENCE ENGINE v14
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('buildsync_v14_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [broadcasts, setBroadcasts] = useState<BroadcastRequest[]>(() => {
    const saved = localStorage.getItem('buildsync_v14_broadcasts');
    return saved ? JSON.parse(saved) : []; 
  });

  const [collections, setCollections] = useState<Collection[]>(() => {
    const saved = localStorage.getItem('buildsync_v14_collections');
    return saved ? JSON.parse(saved) : [{ id: 'default', name: 'General Builds', postIds: [] }];
  });

  const [savedCards, setSavedCards] = useState<SavedCard[]>(() => {
    const saved = localStorage.getItem('buildsync_v14_cards');
    return saved ? JSON.parse(saved) : [
      { id: 'c1', brand: 'visa', last4: '4242', expiry: '12/25', isDefault: true, nickname: 'Main Workspace Card' },
      { id: 'c2', brand: 'mastercard', last4: '8812', expiry: '08/24', isDefault: false, nickname: 'Supplies Card' }
    ];
  });

  const [bankAccount, setBankAccount] = useState<BankAccount | null>(() => {
    const saved = localStorage.getItem('buildsync_v14_bank');
    return saved ? JSON.parse(saved) : null;
  });

  const [wallPosts, setWallPosts] = useState<WallPost[]>(() => {
    const saved = localStorage.getItem('buildsync_v14_wallposts');
    return saved ? JSON.parse(saved) : MOCK_WALL_POSTS;
  });

  const [userEmail, setUserEmail] = useState<string>(() => {
    return localStorage.getItem('buildsync_v14_email') || 'sarah.jenkins@buildsync.com';
  });

  const [userPhone, setUserPhone] = useState<string>(() => {
    return localStorage.getItem('buildsync_v14_phone') || '+1 (555) 234-5678';
  });

  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [selectedExpert, setSelectedExpert] = useState<Professional | null>(null);
  
  // Settings State
  const [isLocked, setIsLocked] = useState(true);
  const [notificationPrefs, setNotificationPrefs] = useState([true, false, true, true]);

  // UI States
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeProjectTab, setActiveProjectTab] = useState<'ai' | 'expert' | 'vault' | 'summaries'>('ai');
  
  // Tool States
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [isAudioOnly, setIsAudioOnly] = useState(false);
  const [liveTranscription, setLiveTranscription] = useState('');
  const [isWhiteboardOpen, setIsWhiteboardOpen] = useState(false);
  const [isDrivePickerOpen, setIsDrivePickerOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [offerBroadcastId, setOfferBroadcastId] = useState<string | null>(null);
  const [pendingSnapshot, setPendingSnapshot] = useState<string | undefined>(undefined);

  const scrollRef = useRef<HTMLDivElement>(null);
  const mainInputRef = useRef<HTMLInputElement>(null);
  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const liveSessionRef = useRef<LiveCallSession | null>(null);

  const activeProject = projects.find(p => p.id === activeProjectId);

  // Mandatory Persistence Sync
  useEffect(() => { localStorage.setItem('buildsync_v14_projects', JSON.stringify(projects)); }, [projects]);
  useEffect(() => { localStorage.setItem('buildsync_v14_broadcasts', JSON.stringify(broadcasts)); }, [broadcasts]);
  useEffect(() => { localStorage.setItem('buildsync_v14_collections', JSON.stringify(collections)); }, [collections]);
  useEffect(() => { localStorage.setItem('buildsync_v14_cards', JSON.stringify(savedCards)); }, [savedCards]);
  useEffect(() => { localStorage.setItem('buildsync_v14_bank', JSON.stringify(bankAccount)); }, [bankAccount]);
  useEffect(() => { localStorage.setItem('buildsync_v14_wallposts', JSON.stringify(wallPosts)); }, [wallPosts]);
  useEffect(() => { localStorage.setItem('buildsync_v14_email', userEmail); }, [userEmail]);
  useEffect(() => { localStorage.setItem('buildsync_v14_phone', userPhone); }, [userPhone]);

  useEffect(() => {
    const checkKey = async () => {
      try {
        // @ts-ignore
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(hasKey);
      } catch (e) { setHasApiKey(false); }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    try {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    } catch (e) {
      console.error("Key selection failed", e);
    }
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [activeProject, isTyping, activeProjectTab]);

  const addNotification = (message: string, type: AppNotification['type']) => {
    const note = { id: Date.now().toString(), message, type };
    setNotifications(prev => [...prev, note]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== note.id)), 5000);
  };

  const handleSendMessage = async (text: string = inputText, imageBase64?: string) => {
    if (!hasApiKey) {
      handleSelectKey();
      return;
    }

    const finalImage = imageBase64 || pendingSnapshot;
    if (!text.trim() && !finalImage) return;

    const userMsg: ChatMessage = { 
      id: Date.now().toString(), 
      role: userRole === 'client' ? 'user' : 'expert', 
      text, 
      canvasSnapshot: finalImage 
    };

    let targetId = activeProjectId;
    if (!targetId) {
      targetId = `proj-${Date.now()}`;
      const newProject: Project = {
        id: targetId, title: text.slice(0, 25) + '...', status: 'planning', lastUpdated: 'Just now', summary: text,
        aiMessages: [userMsg], expertMessages: [], media: [], files: [], summaries: []
      };
      setProjects(prev => [newProject, ...prev]);
      setActiveProjectId(targetId);
      setCurrentView(AppView.WORKSPACE);
    } else {
      setProjects(prev => prev.map(p => p.id === targetId ? {
        ...p,
        aiMessages: activeProjectTab === 'ai' ? [...p.aiMessages, userMsg] : p.aiMessages,
        expertMessages: activeProjectTab === 'expert' ? [...p.expertMessages, userMsg] : p.expertMessages,
      } : p));
    }

    if (activeProjectTab === 'ai' || !activeProjectId) {
      setIsTyping(true);
      try {
        const response = await geminiService.getDIYAdvice(text, activeProject?.summary, finalImage);
        const aiMsg: ChatMessage = { 
          id: (Date.now() + 1).toString(), 
          role: 'model', 
          text: response.text,
          generatedImages: response.images,
          groundingSources: response.groundingSources
        };
        setProjects(prev => prev.map(p => p.id === targetId ? { ...p, aiMessages: [...p.aiMessages, aiMsg] } : p));
      } catch (e) { 
        if (e instanceof Error && e.message.includes("Requested entity was not found")) {
          setHasApiKey(false);
          addNotification("Neural bridge session lost. Please re-connect.", "info");
        } else {
          addNotification("AI Bridge communication error.", "info"); 
        }
      } finally { setIsTyping(false); }
    }

    setInputText('');
    setPendingSnapshot(undefined);
  };

  const handleReconnectExpert = () => {
    if (activeProject && activeProject.status === 'completed' && activeProject.assignedProId) {
      setProjects(prev => prev.map(p => p.id === activeProjectId ? {
        ...p,
        status: 'in-progress',
        expertMessages: [...p.expertMessages, {
          id: `sys-${Date.now()}`,
          role: 'system_summary',
          text: `Signal re-established with ${p.assignedProName}. Project reactivated for ongoing collaboration.`
        }]
      } : p));
      addNotification(`Reconnected with ${activeProject.assignedProName}`, "success");
      setActiveProjectTab('expert');
    }
  };

  const handleCreateBroadcast = () => {
    // If project is completed and has an expert, interpret broadcast click as reconnection
    if (activeProject && activeProject.status === 'completed' && activeProject.assignedProId) {
      handleReconnectExpert();
      return;
    }

    const summary = inputText || activeProject?.summary || "General Build Inquiry";
    const newBroadcast: BroadcastRequest = {
      id: `br-${Date.now()}`,
      clientId: 'sarah-123',
      clientName: 'Sarah Jenkins',
      problemSummary: summary,
      category: 'General',
      timestamp: 'Just now',
      status: 'open',
      offers: [],
      urgency: 'medium'
    };
    setBroadcasts(prev => [newBroadcast, ...prev]);
    
    // Switch to expert tab to show the "Broadcast" state
    setActiveProjectTab('expert');
    setInputText('');
    addNotification("Help signal broadcasted to Expert Network. Network listening...", "success");
  };

  const handleExpertOffer = (req: BroadcastRequest) => {
    setBroadcasts(prev => prev.map(r => r.id === req.id ? {
      ...r, 
      status: 'offer_received',
      offers: [...r.offers, 'expert-1'] 
    } : r));
    addNotification(`Offer sent to ${req.clientName}`, "success");
  };

  const handleApproveExpert = (req: BroadcastRequest | null, expert: Professional) => {
    const targetProjId = activeProjectId || `proj-${Date.now()}`;
    const projectExists = projects.some(p => p.id === targetProjId);
    
    if (projectExists) {
      setProjects(prev => prev.map(p => p.id === targetProjId ? {
        ...p,
        status: 'in-progress',
        assignedProId: expert.id,
        assignedProName: expert.name,
        expertMessages: [...p.expertMessages, {
          id: `sys-${Date.now()}`,
          role: 'system_summary',
          text: `Expert ${expert.name} has joined the link. Initial project context transmitted.`
        }]
      } : p));
    } else {
      const summary = req?.problemSummary || "Direct Expert Collaboration";
      const newProj: Project = {
        id: targetProjId,
        title: summary.slice(0, 20) + "...",
        status: 'in-progress',
        lastUpdated: 'Just now',
        summary: summary,
        aiMessages: [],
        expertMessages: [{
          id: `sys-${Date.now()}`,
          role: 'system_summary',
          text: `Expert ${expert.name} has joined the link. Match finalized.`
        }],
        media: [],
        files: [],
        summaries: [],
        assignedProId: expert.id,
        assignedProName: expert.name
      };
      setProjects(prev => [newProj, ...prev]);
      setActiveProjectId(targetProjId);
    }
    
    if (req) {
      setBroadcasts(prev => prev.filter(b => b.id !== req.id));
    }
    setOfferBroadcastId(null);
    setCurrentView(AppView.WORKSPACE);
    setActiveProjectTab('expert');
    addNotification(`Linked with ${expert.name}. Expert Signal established.`, "success");
  };

  const handleSendInvoice = (inv: Omit<Invoice, 'id' | 'status' | 'createdAt'>) => {
    const newInvoice: Invoice = { ...inv, id: `inv-${Date.now()}`, status: 'pending', createdAt: new Date().toLocaleDateString() };
    setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, invoice: newInvoice } : p));
    addNotification("Invoice transmitted to client.", "success");
    setIsInvoiceModalOpen(false);
  };

  const handlePayInvoice = () => {
    setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, invoice: p.invoice ? { ...p.invoice, status: 'paid' } : undefined } : p));
    addNotification("Payment processed successfully.", "success");
  };

  const handleResolveProject = () => {
    setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, status: 'completed' } : p));
    setActiveProjectTab('summaries');
    addNotification("Expert collaboration resolved. Project archived.", "success");
  };

  const handleSavePost = (postId: string, collectionId: string) => {
    setCollections(prev => prev.map(c => {
      if (c.id === collectionId) {
        if (c.postIds.includes(postId)) return c;
        return { ...c, postIds: [...c.postIds, postId] };
      }
      return c;
    }));
    addNotification("Achievement saved to Hub.", "success");
  };

  const handleCreateCollection = (name: string, autoSavePostId?: string) => {
    const newId = `coll-${Date.now()}`;
    const newColl: Collection = { id: newId, name, postIds: autoSavePostId ? [autoSavePostId] : [] };
    setCollections(prev => [...prev, newColl]);
    addNotification(`Archive '${name}' created.`, "success");
    return newId;
  };

  const handleAddWallPost = (content: string, image?: string) => {
    const newPost: WallPost = {
      id: `wall-${Date.now()}`,
      authorName: userRole === 'client' ? 'Sarah Jenkins' : 'Marcus Thorne',
      authorAvatar: `https://picsum.photos/seed/${userRole === 'client' ? 'sarah' : 'marcus'}/100/100`,
      content,
      image,
      likes: 0,
      timestamp: 'Just now',
      tags: ['#new-build', '#neural-update']
    };
    setWallPosts(prev => [newPost, ...prev]);
    addNotification("Neural post shared to Builders Wall.", "success");
  };

  const startLiveSession = async (audioOnly: boolean = false, isScreen: boolean = false) => {
    if (isLiveActive) return;
    let finalStream: MediaStream | undefined;
    if (isScreen) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
        const voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        finalStream = new MediaStream([...screenStream.getVideoTracks(), ...voiceStream.getAudioTracks()]);
        addNotification("Neural Screen Link established.", "success");
      } catch (e) { addNotification("Screen capture authorization denied.", "info"); return; }
    }
    setIsLiveActive(true);
    setIsAudioOnly(audioOnly);
    setLiveTranscription('');
    const session = new LiveCallSession();
    liveSessionRef.current = session;
    setTimeout(async () => {
      await session.start({ onMessage: (msg) => setLiveTranscription(prev => prev + ' ' + msg), onClose: () => setIsLiveActive(false) }, liveVideoRef.current || undefined, activeProject?.summary, finalStream, audioOnly);
    }, 150);
  };

  const stopLiveSession = () => {
    liveSessionRef.current?.stop();
    setIsLiveActive(false);
    liveSessionRef.current = null;
  };

  const SPECIAL_LABS = [
    { id: 'wiring', label: 'Repair Wiring', desc: 'Electrical logic & safety.', prompt: 'Help me repair specific wiring. Analyze for safety protocols and circuit logic.', color: 'bg-amber-50 text-amber-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg> },
    { id: 'leaks', label: 'Fixing Leaks', desc: 'Hydraulic fix & mitigation.', prompt: 'Hydraulic support needed for leak mitigation. Provide immediate shut-off and repair steps.', color: 'bg-blue-50 text-blue-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a2 2 0 00-1.96 1.414l-.727 2.908a2 2 0 00-1.96 1.414H7.931a2 2 0 01-1.96-1.414l-.727-2.908a2 2 0 00-1.96-1.414l-2.387.477a2 2 0 00-1.022.547L1 17v4h22v-4l-3.572-1.572z"/></svg> },
    { id: 'assembly', label: 'Assemble Products', desc: 'Neural manual interpretation.', prompt: 'Analyze product manual for assembly. I will upload images of the parts and instructions.', color: 'bg-emerald-50 text-emerald-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/></svg> },
    { id: 'sourcing', label: 'Sourcing & Price', desc: 'Material logic & better pricing.', prompt: 'Find this product at better prices. Help me source materials with high-efficiency logistics.', color: 'bg-purple-50 text-purple-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg> },
    { id: 'mounting', label: 'Vertical Mounting', desc: 'Structural wall load support.', prompt: 'Structural guidance for mounting. Analyze wall material and weight distribution.', color: 'bg-rose-50 text-rose-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg> },
    { id: 'diy', label: 'DIY Creator', desc: 'Bespoke project creation.', prompt: 'Initiate bespoke DIY project planning. Let\'s design something unique.', color: 'bg-indigo-50 text-indigo-600', icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg> }
  ];

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans">
      {!hasApiKey && (
        <div className="fixed inset-0 z-[2000] bg-slate-900/80 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="bg-white rounded-[3rem] p-12 max-w-xl text-center shadow-2xl border border-white/20 animate-in zoom-in duration-300">
            <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white text-4xl font-black mx-auto mb-8 shadow-xl shadow-indigo-200">B</div>
            <h2 className="text-3xl font-black text-slate-800 mb-4 tracking-tight">Neural Bridge Connection Required</h2>
            <p className="text-slate-500 font-medium mb-8 leading-relaxed">To access BuildSync's specialized AI visualization and technical analysis models, you must connect a valid Gemini API key from a paid project.</p>
            <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 mb-8 text-left">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Protocol Requirements</h4>
              <ul className="text-xs text-slate-600 space-y-2 font-bold">
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293l-4.242 4.242L6.293 9.707a1 1 0 10-1.414 1.414l4.95 4.95a1 1 0 001.414 0l4.95-4.95a1 1 0 00-1.414-1.414z"/></svg> Paid GCP Billing Account</li>
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293l-4.242 4.242L6.293 9.707a1 1 0 10-1.414 1.414l4.95 4.95a1 1 0 001.414 0l4.95-4.95a1 1 0 00-1.414-1.414z"/></svg> Gemini 3 Model Access</li>
              </ul>
            </div>
            <div className="flex flex-col gap-4">
              <button onClick={handleSelectKey} className="w-full bg-indigo-600 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest text-sm shadow-2xl hover:bg-indigo-700 transition-all hover:scale-105 active:scale-95">Connect Neural Bridge</button>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors">Learn about Gemini Billing →</a>
            </div>
          </div>
        </div>
      )}

      <nav className="w-20 md:w-64 bg-white border-r border-slate-200 flex flex-col py-8 px-4 gap-10 shadow-sm">
        <div onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(userRole === 'client' ? AppView.WORKSPACE : AppView.EXPERT_POOL); }} className="flex items-center gap-3 px-2 cursor-pointer group">
          <div className="bg-indigo-600 w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg group-hover:rotate-12 transition-all">B</div>
          <h1 className="hidden md:block font-black text-xl text-indigo-900 leading-none">BuildSync</h1>
        </div>
        <div className="flex flex-col gap-2 flex-1">
          {userRole === 'client' ? (
            <>
              <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.WORKSPACE); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.WORKSPACE && !activeProjectId ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" /></svg>
                <span className="hidden md:block font-bold text-sm">New Build</span>
              </button>
              <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.PROJECT_VAULT); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.PROJECT_VAULT ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                <span className="hidden md:block font-bold text-sm">Project Vault</span>
              </button>
              <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.LOCAL_EXPERTS); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.LOCAL_EXPERTS ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                <span className="hidden md:block font-bold text-sm">Local Experts Lab</span>
              </button>
            </>
          ) : (
            <>
              <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.EXPERT_POOL); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.EXPERT_POOL ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                <span className="hidden md:block font-bold text-sm">Expert Dispatch</span>
              </button>
              <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.EXPERT_PROJECTS); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.EXPERT_PROJECTS ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                <span className="hidden md:block font-bold text-sm">Active Jobs</span>
              </button>
            </>
          )}
          <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.BUILDERS_WALL); }} className={`flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${currentView === AppView.BUILDERS_WALL ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-slate-400 hover:bg-slate-50'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <span className="hidden md:block font-bold text-sm">Builders Wall</span>
          </button>
        </div>
        <button onClick={() => { const newRole = userRole === 'client' ? 'expert' : 'client'; setUserRole(newRole); setCurrentView(newRole === 'client' ? AppView.WORKSPACE : AppView.EXPERT_POOL); setActiveProjectId(null); setSelectedExpert(null); }} className="mt-auto bg-slate-900 text-white px-4 py-5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:shadow-xl transition-all text-center">
           {userRole === 'client' ? 'Go Expert Console' : 'Go Client Mode'}
        </button>
      </nav>
      <main className="flex-1 flex flex-col relative overflow-hidden bg-slate-50/50">
        <header className="bg-white border-b border-slate-200 py-5 px-10 flex justify-between items-center z-10 shadow-sm">
          <div className="flex items-center gap-4">
             {activeProjectId && (
               <button 
                  onClick={() => { setActiveProjectId(null); setCurrentView(userRole === 'client' ? AppView.PROJECT_VAULT : AppView.EXPERT_PROJECTS); }}
                  className="p-2 hover:bg-slate-50 rounded-xl transition-all text-slate-400 hover:text-indigo-600 group flex items-center justify-center mr-2 border border-transparent hover:border-slate-100"
                  title="Back to List"
               >
                 <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
               </button>
             )}
             <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase leading-none">
               {activeProjectId ? activeProject?.title : (currentView === AppView.WORKSPACE ? "BuildSync Workspace" : currentView.replace('_', ' '))}
             </h2>
             {hasApiKey && <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div><span className="text-[8px] font-black text-emerald-600 uppercase tracking-widest">Neural Link Online</span></div>}
          </div>
          <button onClick={() => { setActiveProjectId(null); setSelectedExpert(null); setCurrentView(AppView.CLIENT_SETTINGS); }} className="flex items-center gap-3 hover:bg-slate-50 p-2 rounded-2xl transition-all border border-transparent hover:border-slate-100">
             <div className="text-right hidden sm:block">
                <p className="text-xs font-black text-slate-800">{userRole === 'client' ? 'Sarah Jenkins' : 'Marcus Thorne'}</p>
                <p className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">{userRole === 'client' ? 'Alpha Member' : 'Verified Expert'}</p>
             </div>
             <img src={`https://picsum.photos/seed/${userRole === 'client' ? 'sarah' : 'marcus'}/100/100`} className="w-10 h-10 rounded-2xl border-2 border-slate-100 shadow-sm" />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto p-6 md:p-10">
          {currentView === AppView.CLIENT_SETTINGS ? (
            <ClientSettingsView 
              onBack={() => setCurrentView(userRole === 'client' ? AppView.WORKSPACE : AppView.EXPERT_POOL)} 
              userRole={userRole} 
              isLocked={isLocked} 
              setIsLocked={setIsLocked} 
              notificationPrefs={notificationPrefs} 
              setNotificationPrefs={setNotificationPrefs} 
              collections={collections} 
              allPosts={wallPosts} 
              onCreateCollection={handleCreateCollection} 
              savedCards={savedCards} 
              setSavedCards={setSavedCards} 
              bankAccount={bankAccount} 
              setBankAccount={setBankAccount}
              userEmail={userEmail}
              setUserEmail={setUserEmail}
              userPhone={userPhone}
              setUserPhone={setUserPhone}
            />
          ) : activeProjectId && activeProject ? (
            <div className="max-w-6xl mx-auto h-full flex flex-col bg-white rounded-[3.5rem] border border-slate-200 overflow-hidden shadow-2xl animate-in fade-in slide-in-from-bottom-8 duration-700 relative">
               <div className="bg-slate-50/50 border-b border-slate-200 px-10 py-2 flex gap-10">
                  {(['ai', 'expert', 'vault', 'summaries'] as const).map(tab => (
                    <button key={tab} onClick={() => setActiveProjectTab(tab)} className={`text-[10px] font-black uppercase tracking-widest py-5 border-b-2 transition-all relative ${activeProjectTab === tab ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>{tab === 'ai' ? 'Neural Link' : tab === 'expert' ? 'Expert Signal' : tab === 'vault' ? 'Site Data' : 'Milestones'}</button>
                  ))}
               </div>
               <div className="flex-1 flex flex-col relative bg-white overflow-hidden">
                  {activeProjectTab === 'expert' && (
                    <div className="bg-slate-900 px-10 py-4 flex justify-between items-center text-white z-10 shadow-lg border-b border-white/10">
                       <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full animate-pulse ${activeProject.status === 'planning' ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
                          <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
                             {activeProject.status === 'planning' ? 'Awaiting verified match...' : activeProject.status === 'completed' ? 'Verified Session Archive' : 'Verified Signal Active'}
                          </span>
                       </div>
                       <div className="flex gap-3">
                          {activeProject.status === 'planning' && (
                             <div className="flex items-center gap-4">
                                {broadcasts.find(b => b.problemSummary.includes(activeProject.summary.slice(0, 10)))?.offers.length ? (
                                   <button 
                                      onClick={() => {
                                         const b = broadcasts.find(b => b.problemSummary.includes(activeProject.summary.slice(0, 10)));
                                         if (b) setOfferBroadcastId(b.id);
                                      }}
                                      className="bg-emerald-500 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg animate-bounce"
                                   >
                                      View {broadcasts.find(b => b.problemSummary.includes(activeProject.summary.slice(0, 10)))?.offers.length} Expert Offers
                                   </button>
                                ) : (
                                   <span className="text-[10px] font-black text-amber-500 uppercase tracking-[0.2em] italic">Broadcasting Signal...</span>
                                )}
                             </div>
                          )}
                          {activeProject.status === 'in-progress' && (
                            <>
                              {userRole === 'expert' && !activeProject.invoice && (
                                <button onClick={() => setIsInvoiceModalOpen(true)} className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg transition-all">Create Invoice</button>
                              )}
                              {userRole === 'client' && activeProject.invoice && activeProject.invoice.status === 'pending' && (
                                <button onClick={handlePayInvoice} className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg transition-all animate-bounce">Pay ${activeProject.invoice.amount}</button>
                              )}
                              <button onClick={handleResolveProject} className="bg-white/10 hover:bg-white/20 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">End Conversation</button>
                            </>
                          )}
                          {activeProject.status === 'completed' && (
                            <div className="flex items-center gap-3">
                              <span className="bg-emerald-500/20 text-emerald-400 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-emerald-500/30">Verified Closed</span>
                              {userRole === 'client' && activeProject.assignedProId && (
                                <button 
                                  onClick={handleReconnectExpert}
                                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg transition-all flex items-center gap-2"
                                >
                                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                                  Reconnect with {activeProject.assignedProName.split(' ')[0]}
                                </button>
                              )}
                            </div>
                          )}
                       </div>
                    </div>
                  )}

                  <div ref={scrollRef} className="flex-1 overflow-y-auto p-10">
                    {activeProjectTab === 'ai' || activeProjectTab === 'expert' ? (
                      <div className="space-y-12">
                        {activeProjectTab === 'expert' && activeProject.status === 'planning' && activeProject.expertMessages.length === 0 && (
                           <div className="py-20 text-center space-y-8 max-w-xl mx-auto bg-slate-50 rounded-[3.5rem] border border-dashed border-slate-200">
                              <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto text-indigo-600 animate-pulse shadow-inner">
                                 <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                              </div>
                              <div>
                                 <h4 className="text-xl font-black text-slate-800 uppercase tracking-tight">Signal Broadcasted</h4>
                                 <p className="text-slate-400 text-sm font-medium mt-2 leading-relaxed">The expert network has been alerted to your build requirement. Once a professional offers support, you can finalize the link here.</p>
                              </div>
                           </div>
                        )}
                        {(activeProjectTab === 'ai' ? activeProject.aiMessages : activeProject.expertMessages).map(msg => {
                          const isMe = msg.role === (userRole === 'client' ? 'user' : 'expert');
                          return (
                            <div key={msg.id} className={`flex items-start gap-4 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                               <img src={isMe ? (userRole === 'client' ? 'https://picsum.photos/seed/sarah/100/100' : 'https://picsum.photos/seed/marcus/100/100') : (activeProjectTab === 'ai' ? 'https://picsum.photos/seed/ai/100/100' : 'https://picsum.photos/seed/marcus/100/100')} className="w-10 h-10 rounded-2xl border-2 border-slate-100 shadow-sm flex-shrink-0 mt-1" />
                               <div className={`max-w-[75%] p-8 rounded-[2.5rem] shadow-sm ${isMe ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100'}`}>
                                  <p className="text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                                  {msg.canvasSnapshot && <img src={msg.canvasSnapshot} className="mt-6 rounded-[2rem] max-h-72 border border-white/20 shadow-lg" />}
                                  {msg.generatedImages?.map((img, i) => (
                                    <div key={i} className="mt-6 rounded-[2.5rem] overflow-hidden border-4 border-white shadow-2xl">
                                      <img src={img} className="w-full h-auto object-cover" alt="Neural Render" />
                                    </div>
                                  ))}
                               </div>
                            </div>
                          );
                        })}
                        {isTyping && <div className="flex gap-2 p-6"><div className="w-2.5 h-2.5 bg-indigo-600 rounded-full animate-bounce"></div><div className="w-2.5 h-2.5 bg-indigo-600 rounded-full animate-bounce delay-100"></div><div className="w-2.5 h-2.5 bg-indigo-600 rounded-full animate-bounce delay-200"></div></div>}
                      </div>
                    ) : activeProjectTab === 'vault' ? (
                      <div className="space-y-12">
                         <section>
                            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Site Media</h3>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                               {activeProject.media.map(m => (<div key={m.id} className="aspect-square bg-slate-50 rounded-3xl border border-slate-100 overflow-hidden"><img src={m.url} className="w-full h-full object-cover" /></div>))}
                               <button onClick={() => setIsCameraOpen(true)} className="aspect-square bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-3 text-slate-400 hover:bg-indigo-50 transition-all"><svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg><span className="text-[10px] font-black uppercase">Add Photo</span></button>
                            </div>
                         </section>
                      </div>
                    ) : (
                      <div className="space-y-6">
                         <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Neural Project Milestones</h3>
                         {activeProject.summaries.map(s => (<div key={s.id} className="bg-slate-50 border border-slate-100 p-8 rounded-[2.5rem] relative overflow-hidden group hover:bg-white hover:shadow-xl transition-all"><div className="absolute top-0 right-0 p-8"><span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">{s.date}</span></div><h4 className="text-xl font-black text-slate-800 mb-4 tracking-tight">{s.title}</h4><p className="text-sm text-slate-500 leading-relaxed font-medium whitespace-pre-wrap">{s.content}</p></div>))}
                      </div>
                    )}
                  </div>
                  {(activeProjectTab === 'ai' || activeProjectTab === 'expert') && (
                    <div className="p-8 border-t border-slate-100 bg-slate-50/50 space-y-4">
                      <div className="flex flex-wrap gap-2 px-4">
                         <button onClick={() => setIsCameraOpen(true)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812-1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                           Snapshot
                         </button>
                         <button onClick={() => setIsWhiteboardOpen(true)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                           Workbench
                         </button>
                         <button onClick={() => startLiveSession(false)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                           Video Call
                         </button>
                         <button onClick={() => startLiveSession(true)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 11-6 0z" clipRule="evenodd" /></svg>
                           Audio Call
                         </button>
                         <button onClick={() => startLiveSession(false, true)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-slate-500 hover:border-indigo-400 hover:text-indigo-600 transition-all shadow-sm">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                           Screen Share
                         </button>
                         <button onClick={handleCreateBroadcast} className="flex items-center gap-2 bg-amber-500 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all shadow-md">
                           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" /></svg>
                           {activeProject?.status === 'completed' && activeProject?.assignedProId ? 'Reconnect' : 'Broadcast'}
                         </button>
                      </div>
                      <div className="flex gap-4 bg-white p-4 rounded-[3.5rem] shadow-2xl border border-slate-200 ring-8 ring-slate-100/50">
                         <input value={inputText} onChange={e => setInputText(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSendMessage()} className="flex-1 px-8 py-4 text-base focus:outline-none font-medium text-slate-700 placeholder:text-slate-300" placeholder="Type a message or deploy a tool..." />
                         <button onClick={() => handleSendMessage()} className="bg-indigo-600 text-white px-10 py-4 rounded-[3rem] font-black uppercase tracking-widest text-[11px] shadow-xl hover:bg-indigo-700 transition-all">Transmit</button>
                      </div>
                    </div>
                  )}
               </div>
            </div>
          ) : currentView === AppView.LOCAL_EXPERTS ? (
            selectedExpert ? (
              <ProfileView 
                pro={selectedExpert} 
                onBack={() => setSelectedExpert(null)} 
                isClientViewing={true}
                onConnect={() => { handleApproveExpert(null, selectedExpert); setSelectedExpert(null); }}
              />
            ) : (
              <LocalExpertsList 
                onCall={(pro) => handleApproveExpert(null, pro)} 
                onViewProfile={(pro) => setSelectedExpert(pro)}
              />
            )
          ) : currentView === AppView.WORKSPACE ? (
            <div className="max-w-6xl mx-auto min-h-full flex flex-col items-center justify-start text-center space-y-16 animate-in fade-in duration-1000 pb-32 pt-16">
               <div className="space-y-8 max-w-5xl px-4 text-center">
                  <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter leading-tight">A platform to connect builders with people who want to build.</h2>
                  <p className="text-slate-500 text-lg md:text-xl font-medium leading-relaxed max-w-4xl mx-auto italic">Neural site support, specialized verified expert networks, and collaborative project management for visionaries.</p>
               </div>
               <div className="w-full max-w-3xl bg-white p-5 rounded-[3.5rem] shadow-2xl border border-slate-200 flex gap-4 ring-[12px] ring-indigo-50/50 mb-4 mx-4">
                  <input ref={mainInputRef} value={inputText} onChange={e => setInputText(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSendMessage()} className="flex-1 px-8 py-5 text-xl focus:outline-none font-medium placeholder:text-slate-300" placeholder="Start your build journey..." />
                  <button onClick={() => handleSendMessage()} className="bg-indigo-600 text-white px-12 py-5 rounded-[3rem] font-black uppercase tracking-widest text-xs shadow-2xl hover:bg-indigo-700 hover:scale-105 transition-all">Initiate</button>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl px-4">
                  {SPECIAL_LABS.map(lab => (
                    <button 
                      key={lab.id} 
                      onClick={() => {
                        setInputText(lab.prompt);
                        mainInputRef.current?.focus();
                      }} 
                      className="bg-white border border-slate-100 p-8 rounded-[2.5rem] flex flex-col items-start text-left group hover:border-indigo-400 hover:shadow-2xl hover:-translate-y-2 transition-all"
                    >
                       <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 shadow-sm border ${lab.color}`}>{lab.icon}</div>
                       <h4 className="text-base font-black text-slate-800 uppercase tracking-widest mb-2 group-hover:text-indigo-600">{lab.label}</h4>
                       <p className="text-xs text-slate-400 font-bold leading-relaxed">{lab.desc}</p>
                    </button>
                  ))}
               </div>
            </div>
          ) : currentView === AppView.BUILDERS_WALL ? (
            <div className="max-w-2xl mx-auto space-y-8 pb-20">
               {/* BuildersWall direct render */}
               <BuildersWall wallPosts={wallPosts} onAddPost={handleAddWallPost} collections={collections} onSavePost={handleSavePost} onCreateCollection={handleCreateCollection} />
            </div>
          ) : currentView === AppView.PROJECT_VAULT ? (
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
               {projects.map(p => (<div key={p.id} onClick={() => { setActiveProjectId(p.id); setCurrentView(AppView.WORKSPACE); }} className="bg-white p-12 rounded-[3.5rem] border border-slate-200 shadow-sm hover:shadow-2xl transition-all cursor-pointer group hover:-translate-y-3 duration-500"><span className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest mb-8 inline-block shadow-sm ${p.status === 'completed' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-indigo-100 text-indigo-700 border-indigo-200'}`}>{p.status}</span><h3 className="text-3xl font-black text-slate-800 mb-6 group-hover:text-indigo-600 transition-colors tracking-tighter">{p.title}</h3><p className="text-base text-slate-500 line-clamp-2 leading-relaxed font-medium">{p.summary}</p></div>))}
            </div>
          ) : currentView === AppView.EXPERT_POOL ? (
            <ExpertDashboard requests={broadcasts} onOfferHelp={handleExpertOffer} />
          ) : currentView === AppView.EXPERT_PROJECTS ? (
            <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-500 pb-20">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Active Expert Jobs</h2>
                <p className="text-slate-500 font-medium">Ongoing projects and active client signals you have accepted.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                 {projects.filter(p => p.assignedProId === 'expert-1' && p.status !== 'completed').map(p => (
                   <div key={p.id} onClick={() => { setActiveProjectId(p.id); setCurrentView(AppView.WORKSPACE); setActiveProjectTab('expert'); }} className="bg-white p-10 rounded-[3.5rem] border-2 border-indigo-100 shadow-sm hover:shadow-2xl transition-all cursor-pointer group hover:-translate-y-2 duration-300">
                     <div className="flex justify-between items-start mb-6">
                        <span className="px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest bg-emerald-100 text-emerald-700 border border-emerald-200">Live Connection</span>
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                     </div>
                     <h3 className="text-2xl font-black text-slate-800 mb-4 group-hover:text-indigo-600 transition-colors tracking-tight">{p.title}</h3>
                     <p className="text-sm text-slate-500 line-clamp-2 leading-relaxed font-medium mb-8">"{p.summary}"</p>
                     <div className="flex items-center justify-between border-t border-slate-50 pt-6">
                        <div className="flex items-center gap-3">
                           <img src="https://picsum.photos/seed/sarah/100/100" className="w-8 h-8 rounded-lg" alt="Client" />
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sarah Jenkins</span>
                        </div>
                        <button className="text-indigo-600 font-black uppercase text-[10px] tracking-widest group-hover:underline">Open Chat →</button>
                     </div>
                   </div>
                 ))}
                 {projects.filter(p => p.assignedProId === 'expert-1' && p.status !== 'completed').length === 0 && (
                   <div className="col-span-full py-40 text-center bg-white rounded-[3rem] border-2 border-dashed border-slate-100">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                         <svg className="w-10 h-10 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                      </div>
                      <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-sm">No Active Jobs Found.</p>
                      <p className="text-slate-300 text-xs mt-2 font-medium">Head to 'Expert Dispatch' to find new build opportunities.</p>
                   </div>
                 )}
              </div>
            </div>
          ) : null}
        </div>
      </main>
      
      {offerBroadcastId && (
         <MultiOfferModal 
            broadcast={broadcasts.find(b => b.id === offerBroadcastId)!}
            pros={MOCK_PROS.filter(p => broadcasts.find(b => b.id === offerBroadcastId)?.offers.includes(p.id))}
            onClose={() => setOfferBroadcastId(null)}
            onApprove={handleApproveExpert}
         />
      )}

      {isWhiteboardOpen && <Whiteboard onClose={() => setIsWhiteboardOpen(false)} onSendToAI={(snap, prompt) => { handleSendMessage(prompt, snap); setIsWhiteboardOpen(false); }} />}
      {isCameraOpen && <CameraCapture onCapturePhoto={(snap) => { if (activeProjectId) { setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, media: [...p.media, { id: Date.now().toString(), url: snap, type: 'photo', name: 'Site Photo', timestamp: 'Just now' }] } : p)); addNotification("Photo saved to Site Data.", "success"); } else { handleSendMessage("Analyze snapshot:", snap); } setIsCameraOpen(false); }} onEditPhoto={() => setIsCameraOpen(false)} onClose={() => setIsCameraOpen(false)} />}
      {isInvoiceModalOpen && <InvoiceModal onClose={() => setIsInvoiceModalOpen(false)} onSubmit={handleSendInvoice} expertName="Marcus Thorne" />}
      <div className="fixed top-10 right-10 z-[1000] flex flex-col gap-4 pointer-events-none">
        {notifications.map(n => (<div key={n.id} className="pointer-events-auto bg-white/95 backdrop-blur-2xl border border-slate-100 p-6 rounded-[2.5rem] shadow-2xl flex items-center gap-4 animate-in slide-in-from-right duration-500 max-w-sm"><div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 ${n.type === 'success' ? 'bg-emerald-100 text-emerald-700' : 'bg-indigo-100 text-indigo-700'}`}>🚀</div><p className="text-sm font-bold text-slate-800">{n.message}</p></div>))}
      </div>
    </div>
  );
};
export default App;
