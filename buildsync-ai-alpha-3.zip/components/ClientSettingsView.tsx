
import React, { useState } from 'react';
import { Collection, WallPost, SavedCard, BankAccount } from '../types';

interface ClientSettingsViewProps {
  onBack: () => void;
  userRole: 'client' | 'expert';
  isLocked: boolean;
  setIsLocked: (v: boolean) => void;
  notificationPrefs: boolean[];
  setNotificationPrefs: (v: boolean[]) => void;
  collections?: Collection[];
  allPosts?: WallPost[];
  onCreateCollection?: (name: string) => void;
  savedCards: SavedCard[];
  setSavedCards: React.Dispatch<React.SetStateAction<SavedCard[]>>;
  bankAccount: BankAccount | null;
  setBankAccount: (acc: BankAccount | null) => void;
  userEmail: string;
  setUserEmail: (email: string) => void;
  userPhone: string;
  setUserPhone: (phone: string) => void;
}

const DEFAULT_NOTIFICATIONS = [true, false, true, true];

export const ClientSettingsView: React.FC<ClientSettingsViewProps> = ({ 
  onBack, 
  userRole,
  isLocked,
  setIsLocked,
  notificationPrefs,
  setNotificationPrefs,
  collections = [],
  allPosts = [],
  onCreateCollection,
  savedCards,
  setSavedCards,
  bankAccount,
  setBankAccount,
  userEmail,
  setUserEmail,
  userPhone,
  setUserPhone
}) => {
  const [showForm, setShowForm] = useState(false);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({ current: '', new: '', confirm: '' });
  
  const [cardFormData, setCardFormData] = useState({ number: '', expiry: '', cvv: '', nickname: '' });

  // Contact Edit States
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [isEditingPhone, setIsEditingPhone] = useState(false);
  const [tempEmail, setTempEmail] = useState(userEmail);
  const [tempPhone, setTempPhone] = useState(userPhone);

  // Bank Form State
  const [isAddingBank, setIsAddingBank] = useState(false);
  const [bankFormData, setBankFormData] = useState<BankAccount>({
    bankName: '',
    accountHolder: '',
    accountNumber: '',
    routingNumber: '',
    status: 'pending'
  });

  const handleOpenAddForm = () => {
    setEditingCardId(null);
    setCardFormData({ number: '', expiry: '', cvv: '', nickname: '' });
    setShowForm(true);
  };

  const handleSaveCard = () => {
    if (editingCardId) {
      setSavedCards(prev => prev.map(c => {
        if (c.id === editingCardId) {
          const isNewNumber = !cardFormData.number.includes('•');
          return {
            ...c,
            last4: isNewNumber ? cardFormData.number.slice(-4) : c.last4,
            expiry: cardFormData.expiry,
            nickname: cardFormData.nickname || undefined
          };
        }
        return c;
      }));
    } else {
      if (cardFormData.number.length < 16) return;
      const card: SavedCard = {
        id: `c-${Date.now()}`,
        brand: 'visa',
        last4: cardFormData.number.slice(-4),
        expiry: cardFormData.expiry || '12/28',
        isDefault: false,
        nickname: cardFormData.nickname || undefined
      };
      setSavedCards(prev => [...prev, card]);
    }
    setShowForm(false);
    setEditingCardId(null);
  };

  const handleDeleteCard = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSavedCards(prev => prev.filter(card => card.id !== id));
  };

  const handleSaveBank = () => {
    if (!bankFormData.bankName || !bankFormData.accountNumber) return;
    setBankAccount({ ...bankFormData, status: 'verified' });
    setIsAddingBank(false);
  };

  const handleCreateGroup = () => {
    if (!newGroupName.trim() || !onCreateCollection) return;
    onCreateCollection(newGroupName);
    setNewGroupName('');
    setIsCreatingGroup(false);
  };

  const handleTogglePref = (index: number) => {
    if (isLocked) return;
    const newPrefs = [...notificationPrefs];
    newPrefs[index] = !newPrefs[index];
    setNotificationPrefs(newPrefs);
  };

  const handleSaveEmail = () => {
    setUserEmail(tempEmail);
    setIsEditingEmail(false);
  };

  const handleSavePhone = () => {
    setUserPhone(tempPhone);
    setIsEditingPhone(false);
  };

  const CardIcon = ({ brand }: { brand: SavedCard['brand'] }) => (
    <div className="w-10 h-6 bg-slate-100 rounded flex items-center justify-center text-[8px] font-black uppercase tracking-tighter text-slate-400 border border-slate-200">
      {brand}
    </div>
  );

  const notificationsList = [
    { label: 'Broadcast Responses', desc: 'Alert me when an expert responds to my build signal.' },
    { label: 'AI Progress Summaries', desc: 'Weekly digests of your project milestones.' },
    { label: 'Security Alerts', desc: 'Immediate notification of new login attempts.' },
    { label: 'Expert Chat Messages', desc: 'Real-time push notifications for active links.' },
  ];

  const savedPostsCount = collections.reduce((acc, curr) => acc + curr.postIds.length, 0);

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex items-center justify-between border-b border-slate-200 pb-6">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-indigo-600">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Account Details</h2>
            <p className="text-slate-500 font-medium text-sm">Manage your security, contact information, and archives.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Saved Builds Hub */}
        <section className="bg-white p-10 rounded-[3rem] shadow-2xl border border-indigo-100 space-y-8 md:col-span-2 relative overflow-hidden group/hub">
           <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 rounded-full blur-3xl -mr-32 -mt-32 opacity-50"></div>
           <div className="flex items-center justify-between mb-2 relative z-10">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg shadow-indigo-100 text-white">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Saved Builds Hub</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">{savedPostsCount} Insights Archived Permanently</p>
                </div>
              </div>
              <button onClick={() => setIsCreatingGroup(!isCreatingGroup)} className="bg-slate-50 hover:bg-indigo-50 text-indigo-600 px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all border border-transparent hover:border-indigo-100">
                {isCreatingGroup ? 'Cancel' : '+ New Group'}
              </button>
           </div>

           {isCreatingGroup && (
             <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-200 animate-in slide-in-from-top-4 duration-300 relative z-10 flex gap-4 ring-8 ring-slate-100">
                <input autoFocus value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} placeholder="Group Name..." className="flex-1 bg-white border border-slate-200 rounded-2xl px-6 py-4 text-sm font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-inner" />
                <button onClick={handleCreateGroup} disabled={!newGroupName.trim()} className="bg-indigo-600 disabled:bg-slate-300 text-white px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-100 transition-all">Create</button>
             </div>
           )}

           <div className="space-y-12 relative z-10 max-h-[500px] overflow-y-auto pr-4 scrollbar-hide">
              {collections.map(coll => {
                const collPosts = allPosts.filter(p => coll.postIds.includes(p.id));
                return (
                  <div key={coll.id} className="space-y-6">
                    <div className="flex items-center gap-6">
                      <div className="h-px bg-slate-100 flex-1"></div>
                      <h4 className="text-[11px] font-black text-indigo-500 uppercase tracking-[0.3em] whitespace-nowrap">{coll.name}</h4>
                      <div className="h-px bg-slate-100 flex-1"></div>
                    </div>
                    {collPosts.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {collPosts.map(post => (
                          <div key={post.id} className="bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden group/post hover:shadow-xl transition-all duration-500">
                              {post.image && <div className="h-32 relative overflow-hidden"><img src={post.image} className="w-full h-full object-cover" alt="Post" /></div>}
                              <div className="p-5">
                                <div className="flex items-center gap-2 mb-3">
                                    <img src={post.authorAvatar} className="w-6 h-6 rounded-lg" />
                                    <span className="text-[9px] font-black text-slate-800 uppercase">{post.authorName}</span>
                                </div>
                                <p className="text-[11px] text-slate-600 line-clamp-3 leading-relaxed">"{post.content}"</p>
                              </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-12 text-center bg-slate-50/50 rounded-[2.5rem] border-2 border-dashed border-slate-100 text-[10px] font-bold text-slate-300 uppercase italic">Empty Archive</div>
                    )}
                  </div>
                );
              })}
           </div>
        </section>

        {/* Contact Dispatch */}
        <section className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-indigo-100 p-2 rounded-xl text-indigo-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2-2v10a2 2 0 002 2z" /></svg>
            </div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Contact Dispatch</h3>
          </div>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Verified Email</label>
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 shadow-inner overflow-hidden">
                {isEditingEmail ? (
                  <input 
                    autoFocus
                    value={tempEmail}
                    onChange={(e) => setTempEmail(e.target.value)}
                    onBlur={handleSaveEmail}
                    onKeyPress={(e) => e.key === 'Enter' && handleSaveEmail()}
                    className="flex-1 text-sm font-bold text-slate-700 bg-transparent outline-none"
                  />
                ) : (
                  <span className="flex-1 text-sm font-bold text-slate-700 truncate">{userEmail}</span>
                )}
                <button 
                  onClick={() => { if (!isEditingEmail) { setTempEmail(userEmail); setIsEditingEmail(true); } else { handleSaveEmail(); } }} 
                  className="text-[9px] font-black text-indigo-600 uppercase tracking-widest whitespace-nowrap hover:text-indigo-800 transition-colors"
                >
                  {isEditingEmail ? 'Save' : 'Change'}
                </button>
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Neural Phone</label>
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 shadow-inner">
                {isEditingPhone ? (
                  <input 
                    autoFocus
                    value={tempPhone}
                    onChange={(e) => setTempPhone(e.target.value)}
                    onBlur={handleSavePhone}
                    onKeyPress={(e) => e.key === 'Enter' && handleSavePhone()}
                    className="flex-1 text-sm font-bold text-slate-700 bg-transparent outline-none"
                  />
                ) : (
                  <span className="flex-1 text-sm font-bold text-slate-700 truncate">{userPhone}</span>
                )}
                <button 
                  onClick={() => { if (!isEditingPhone) { setTempPhone(userPhone); setIsEditingPhone(true); } else { handleSavePhone(); } }} 
                  className="text-[9px] font-black text-indigo-600 uppercase tracking-widest whitespace-nowrap hover:text-indigo-800 transition-colors"
                >
                  {isEditingPhone ? 'Save' : 'Change'}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Security Link */}
        <section className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-indigo-100 p-2 rounded-xl text-indigo-600">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Security Link</h3>
          </div>
          <div className="space-y-4">
            <button 
              onClick={() => setIsChangingPassword(!isChangingPassword)}
              className={`w-full flex items-center justify-between p-5 rounded-2xl transition-all group text-left ${isChangingPassword ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 border border-slate-100 hover:bg-indigo-50 hover:border-indigo-100'}`}
            >
              <div>
                <p className={`text-sm font-bold ${isChangingPassword ? 'text-white' : 'text-slate-700'}`}>Password & Security</p>
                <p className={`text-[10px] font-bold uppercase mt-1 ${isChangingPassword ? 'text-indigo-200' : 'text-slate-400'}`}>Update Site Credentials</p>
              </div>
              <svg className={`w-4 h-4 transition-all ${isChangingPassword ? 'text-white rotate-90' : 'text-slate-300 group-hover:text-indigo-600'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
            </button>

            {isChangingPassword && (
              <div className="bg-slate-50 p-6 rounded-[2rem] border border-indigo-100 space-y-4 animate-in slide-in-from-top-4 duration-300">
                <input type="password" placeholder="Current Password" value={passwordData.current} onChange={e => setPasswordData({...passwordData, current: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs font-bold" />
                <input type="password" placeholder="New Neural Password" value={passwordData.new} onChange={e => setPasswordData({...passwordData, new: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs font-bold" />
                <input type="password" placeholder="Confirm New Password" value={passwordData.confirm} onChange={e => setPasswordData({...passwordData, confirm: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs font-bold" />
                <button onClick={() => setIsChangingPassword(false)} className="w-full bg-indigo-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all">Commit Password</button>
              </div>
            )}
          </div>
        </section>

        {/* Financial Vault */}
        <section className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 space-y-6 md:col-span-2">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>
                </div>
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Financial Vault</h3>
              </div>
              <div className="flex gap-4">
                 {userRole === 'expert' && (
                   <button onClick={() => setIsAddingBank(true)} className="text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:underline">+ Update Bank Payout</button>
                 )}
                 <button onClick={handleOpenAddForm} className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">+ Add New Card</button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Column: Bank or Cards */}
              <div className="space-y-6">
                {userRole === 'expert' && (
                  <div className="space-y-4">
                    <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Payout Destination</h4>
                    {isAddingBank ? (
                      <div className="bg-emerald-50 p-8 rounded-[3rem] border border-emerald-100 space-y-4 animate-in slide-in-from-top-4 shadow-xl">
                        <input placeholder="Bank Name" value={bankFormData.bankName} onChange={e => setBankFormData({...bankFormData, bankName: e.target.value})} className="w-full bg-white border border-emerald-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                        <input placeholder="Account Holder" value={bankFormData.accountHolder} onChange={e => setBankFormData({...bankFormData, accountHolder: e.target.value})} className="w-full bg-white border border-emerald-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                        <div className="grid grid-cols-2 gap-4">
                          <input placeholder="Account #" value={bankFormData.accountNumber} onChange={e => setBankFormData({...bankFormData, accountNumber: e.target.value})} className="w-full bg-white border border-emerald-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                          <input placeholder="Routing #" value={bankFormData.routingNumber} onChange={e => setBankFormData({...bankFormData, routingNumber: e.target.value})} className="w-full bg-white border border-emerald-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                        </div>
                        <div className="flex gap-3">
                          <button onClick={() => setIsAddingBank(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Cancel</button>
                          <button onClick={handleSaveBank} className="flex-[2] bg-emerald-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase shadow-lg shadow-emerald-100">Link Bank</button>
                        </div>
                      </div>
                    ) : bankAccount ? (
                      <div className="w-full p-6 rounded-[2rem] bg-emerald-50/50 border border-emerald-100 flex items-center justify-between group">
                        <div className="flex items-center gap-5">
                          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm border border-emerald-100">
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                          </div>
                          <div>
                            <p className="text-sm font-black text-slate-800 uppercase tracking-tight">{bankAccount.bankName}</p>
                            <p className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest">Ending in {bankAccount.accountNumber.slice(-4)} • Verified</p>
                          </div>
                        </div>
                        <button onClick={() => setBankAccount(null)} className="text-slate-300 hover:text-rose-500 transition-colors p-2 rounded-xl">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7" /></svg>
                        </button>
                      </div>
                    ) : (
                      <button onClick={() => setIsAddingBank(true)} className="w-full py-12 text-center text-slate-300 border-2 border-dashed border-emerald-100 rounded-[2.5rem] hover:bg-emerald-50 transition-all">
                        <p className="text-[10px] font-black uppercase tracking-[0.4em]">Link Bank Account for Payouts</p>
                      </button>
                    )}
                  </div>
                )}

                <div className="space-y-4">
                  <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Spending Methods</h4>
                  {showForm ? (
                    <div className="bg-slate-50 p-8 rounded-[3rem] border border-indigo-100 space-y-5 animate-in slide-in-from-top-4 shadow-xl">
                      <input placeholder="Nickname" value={cardFormData.nickname} onChange={e => setCardFormData({...cardFormData, nickname: e.target.value})} className="w-full bg-white border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                      <input placeholder="Card Number" value={cardFormData.number} onChange={e => setCardFormData({...cardFormData, number: e.target.value})} className="w-full bg-white border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                      <div className="grid grid-cols-2 gap-4">
                        <input placeholder="MM/YY" value={cardFormData.expiry} onChange={e => setCardFormData({...cardFormData, expiry: e.target.value})} className="w-full bg-white border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                        <input placeholder="CVV" value={cardFormData.cvv} onChange={e => setCardFormData({...cardFormData, cvv: e.target.value})} className="w-full bg-white border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold shadow-inner" />
                      </div>
                      <div className="flex gap-3 pt-2">
                        <button onClick={() => setShowForm(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Cancel</button>
                        <button onClick={handleSaveCard} className="flex-[2] bg-indigo-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase shadow-lg shadow-indigo-100">Add Card</button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {savedCards.map(card => (
                        <div key={card.id} className="w-full flex items-center justify-between p-5 rounded-[2rem] bg-slate-50 border border-slate-100 group">
                          <div className="flex items-center gap-5">
                            <CardIcon brand={card.brand} />
                            <div>
                              <p className="text-sm font-black text-slate-800 uppercase tracking-tight">{card.nickname || `Card ending in ${card.last4}`}</p>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">•••• {card.last4} | Exp {card.expiry}</p>
                            </div>
                          </div>
                          <button onClick={(e) => handleDeleteCard(e, card.id)} className="text-slate-300 hover:text-rose-500 transition-colors p-2 rounded-xl">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Right Column: Quick Pay Buttons */}
              <div className="space-y-4 flex flex-col justify-center">
                <button onClick={() => window.open('https://www.apple.com/apple-pay/', '_blank')} className="flex items-center justify-center gap-3 w-full h-16 bg-black rounded-3xl text-white transition-transform hover:scale-[1.02] shadow-xl">
                  <svg width="24" height="24" viewBox="0 0 170 200" fill="currentColor">
                    <path d="M150.37,130.25c-2.45,5.66-5.35,10.87-8.71,15.66c-8.58,12.23-17.45,24.37-31.29,24.37c-13.37,0-17.69-8.2-33.21-8.2c-15.52,0-20.13,8.02-33.03,8.39c-12.9,0.37-23.09-12.98-31.74-25.3c-17.69-25.21-31.13-71.19-12.71-103.11c9.14-15.84,25.48-25.89,43.34-26.17c13.73-0.21,26.68,9.28,35.12,9.28c8.44,0,24.13-11.49,40.58-9.84c6.88,0.28,26.21,2.77,38.64,20.94c-1.01,0.62-23,13.41-22.72,39.32C135.03,98.6,146.95,116.1,150.37,130.25z M119.11,32.64c7.34-8.9,12.23-21.25,10.87-33.64c-10.63,0.43-23.49,7.09-31.13,16c-6.84,7.86-12.83,20.5-11.23,32.48C98.98,48.24,111.47,41.9,119.11,32.64z"/>
                  </svg>
                  <span className="font-black text-2xl tracking-tighter">Apple Pay</span>
                </button>
                <button onClick={() => window.open('https://pay.google.com/', '_blank')} className="flex items-center justify-center gap-4 w-full h-16 bg-white border-2 border-slate-200 rounded-3xl transition-transform hover:scale-[1.02] shadow-lg">
                  <svg width="24" height="24" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24s.92 7.54 2.56 10.78l7.97-6.19z"/>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                  </svg>
                  <span className="font-black text-slate-800 uppercase tracking-widest text-sm">Google Pay</span>
                </button>
              </div>
            </div>
        </section>

        {/* Neural Notifications */}
        <section className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 space-y-6 md:col-span-2">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-indigo-100 p-2 rounded-xl text-indigo-600">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
            </div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Neural Notifications</h3>
            {isLocked && <span className="text-[8px] font-black uppercase text-indigo-400 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">Locked</span>}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
            {notificationsList.map((pref, i) => (
              <div key={pref.label} className={`flex items-center justify-between py-5 border-b border-slate-50 last:border-0 transition-all ${isLocked ? 'opacity-40' : 'opacity-100'}`}>
                <div className="flex-1 pr-4">
                  <p className="text-sm font-black text-slate-700 uppercase tracking-tight">{pref.label}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 italic">{pref.desc}</p>
                </div>
                <input type="checkbox" checked={notificationPrefs[i]} onChange={() => handleTogglePref(i)} disabled={isLocked} className="w-5 h-5 rounded border-2 border-indigo-200 text-indigo-600 focus:ring-indigo-500 cursor-pointer" />
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="flex justify-end gap-6 pt-12 pb-24">
        <button onClick={() => { setNotificationPrefs(DEFAULT_NOTIFICATIONS); setIsLocked(false); }} className="px-8 py-4 font-black uppercase text-[10px] tracking-widest text-slate-400 hover:text-slate-600 transition-all">Reset Defaults</button>
        <button onClick={() => setIsLocked(true)} className="bg-slate-900 text-white px-12 py-4 rounded-2xl font-black uppercase text-[10px] shadow-2xl hover:bg-indigo-600 transition-all active:scale-95">Save Preferences</button>
      </div>
    </div>
  );
};
